Sirbu Maria-Dorinela
332CB - Tema 2 POO

	Pentru implementarea acestei teme am utilizat scheletul de cod dat si am mai creat urmatoarele clase:
	
	In pachetul Shapes:
		-Clasa Dreptunghi: in aceasta clasa calculez varfurile dreptunghiului si il desenez;
		-Clasa Patrat: in aceasta clasa calculez varfurile patratului si il desenez;
		-Clasa Triunghi: in aceasta clasa calculez varfurile triunghiului si il desenez;
		-Clasa Romb: in aceasta clasa calculez varfurile rombului si il desenez;
		-Clasa Punct: in care desenez un punct;
		
	In pachetul Projectiles:
		-Clasa CanisterShot care extinde Clasa HeatedShot;
		-Clasa Carcass care extinde Clasa HeatedShot;
		-Clasa ChainShot care extinde Clasa Shrapnel;
		-Clasa HeatedShot care extinde Clasa SpiderShot;
		-Clasa Shrapnel care extinde Clasa SpiderShot;
		-Clasa SimpleShell care extinde Clasa Projectile;
		-Clasa SpiderShot care extinde Clasa SimpleShell;
		-Clasa TrigrapeShot care extinde Clasa Shrapnel;
		
	Clasa Main (contine metoda main) in care citesc din fisier si pentru fiecare tip de proiectil calculez datele necesare proiectarii pe ecran si completez matricea 
    Tot in Clasa Main fac si scrierea in fisier
	
	In aceste clase am pus comentarii pentru fiecare metoda. Deasemenea, in Clasa Main am comentat liniile scrise cu ce am facut(este mai usor de urmarit codul insotit de comentarii).
	
	In tema am implementat ierarhia de clase necesara pentru obtinerea bonusului.