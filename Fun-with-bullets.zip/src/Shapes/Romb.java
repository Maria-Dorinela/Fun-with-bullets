package Shapes;

import Constants.Symbols;
import Screen.Screen;
/**
 * Clasa Romb in care calculez punctele asociate colturilor unui romb in functie de centrul de greutate
 * si desenez romb.
 * Aceasta clasa extinde Clasa BasicShape
 * @author Dorinela
 *
 */
public class Romb extends BasicShape{
	
	@Override
	public void draw(Screen screen, int ref, Point centerGrav) {
		// TODO Auto-generated method stub
		
		Point[] startP = new Point[2];
		Point[] endP = new Point[2];
		
		Point varf_sus = centerGrav.translate(0, -2*ref);
		Point varf_jos = centerGrav.translate(0, 2*ref);
		Point varf_dreapta = centerGrav.translate(ref, 0);
		Point varf_stanga = centerGrav.translate(-ref, 0);
		
		startP[0] = varf_dreapta;
		startP[1] = varf_stanga;
		
		endP[0] = varf_jos;
		endP[1] = varf_sus;
		
		screen.drawMultipleLinesOnScreen(startP, endP, Symbols.RHOMBUS_SYMBOL);
		screen.drawMultipleLinesOnScreen(startP, endP, Symbols.RHOMBUS_SYMBOL);
	
	}
}
