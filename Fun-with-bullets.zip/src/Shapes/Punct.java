package Shapes;

import Screen.Screen;
import Constants.Symbols;
/**
 * Desenarea unui punct.
 * Aceasta clasa extinde Clasa BasicShape
 * @author Dorinela
 *
 */
public class Punct extends BasicShape{
	int xx,yy;

	@Override
	public void draw(Screen screen, int ref, Point centerGrav) {
		// TODO Auto-generated method stub
		screen.drawLineOnScreen(centerGrav, centerGrav, Symbols.DOT_SYMBOL);
		
	}

}
