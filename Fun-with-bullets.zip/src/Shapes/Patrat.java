package Shapes;

import Constants.Symbols;
import Screen.Screen;
/**
 * Clasa Patrat in care calculez punctele asociate colturilor unui patrat in functie de centrul de greutate
 * si desenez patratul.
 * Aceasta clasa extinde Clasa BasicShape
 * @author Dorinela
 *
 */
public class Patrat extends BasicShape{

	
	@Override
	public void draw(Screen screen, int ref, Point centerGrav) {
		// TODO Auto-generated method stub
		Symbols s = new Symbols();
		Point[] startP = new Point[2];
		Point[] endP = new Point[2];
		
		
		
		Point varf_sus_dreapta = centerGrav.translate(ref, -ref);
		Point varf_sus_stanga = centerGrav.translate(-ref, -ref);
		Point varf_jos_dreapta = centerGrav.translate(ref, ref);
		Point varf_jos_stanga = centerGrav.translate(-ref, ref);
		
		
		startP[0] = varf_sus_dreapta;
		startP[1] = varf_jos_stanga;
		
		endP[0] = varf_sus_stanga;
		endP[1] = varf_jos_dreapta;
		
		screen.drawMultipleLinesOnScreen(startP, endP, s.SQUARE_SYMBOL);
		
	}

}
