package Shapes;

import Constants.Symbols;
import Screen.Screen;
/**
 * Clasa Dreptunghi in care calculez punctele asociate colturilor unui dreptunghi in functie de centrul de greutate
 * si desenez dreptunghiul.
 * Aceasta clasa extinde Clasa BasicShape
 * @author Dorinela
 *
 */
public class Dreptunghi extends BasicShape{
	
	public void draw(Screen screen, int ref, Point centerGrav) {
		// TODO Auto-generated method stub
		
		Point[] startP = new Point[2];
		Point[] endP = new Point[2];
		
		Point varf_sus_dreapta = centerGrav.translate(2*ref, -ref);
		Point varf_sus_stanga = centerGrav.translate(-2*ref, -ref);
		Point varf_jos_dreapta = centerGrav.translate(2*ref, ref);
		Point varf_jos_stanga = centerGrav.translate(-2*ref, ref);
	
		startP[0] = varf_sus_dreapta;
		startP[1] = varf_jos_stanga;
		
		endP[0] = varf_sus_stanga;
		endP[1] = varf_jos_dreapta;
		
		//screen.drawMultipleLinesOnScreen(startP, endP, Symbols.RECTANGLE_SYMBOL);
		screen.drawLineOnScreen(varf_sus_dreapta, varf_jos_dreapta, Symbols.RECTANGLE_SYMBOL);
		screen.drawLineOnScreen(varf_jos_dreapta, varf_jos_stanga, Symbols.RECTANGLE_SYMBOL);
		screen.drawLineOnScreen(varf_jos_stanga, varf_sus_stanga, Symbols.RECTANGLE_SYMBOL);
		screen.drawLineOnScreen(varf_sus_stanga, varf_sus_dreapta, Symbols.RECTANGLE_SYMBOL);
		
	}

}
