package Shapes;

import Screen.Screen;
import Constants.*;

/**
 * Clasa Triunghi in care calculez punctele asociate colturilor unui triunghi in functie de centrul de greutate
 * si desenez triunghiul.
 * Aceasta clasa extinde Clasa BasicShape
 * @author Dorinela
 *
 */
public class Triunghi extends BasicShape{
	
	@Override
	public void draw(Screen screen, int ref, Point centerGrav) {
		// TODO Auto-generated method stub
		Point[] startP = new Point[2];
		Point[] endP = new Point[2];

		Point varf_sus = centerGrav.translate(0, -2*ref);
		Point varf_dreapta = centerGrav.translate(ref, ref);
		Point varf_stanga = centerGrav.translate(-ref, ref);
		
		startP[0] = varf_sus;
		startP[1] = varf_stanga;
		
		endP[0] = varf_dreapta;
		endP[1] = varf_stanga;
		
		screen.drawMultipleLinesOnScreen(startP, endP, Symbols.TRIANGLE_SYMBOL);
		
	}

}
