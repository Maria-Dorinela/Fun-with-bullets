import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;

import javax.print.attribute.standard.Finishings;

import Constants.*;
import ProcessingManagers.*;
import Screen.*;
import Shapes.*;
import Projectiles.*;

/**
 * Clasa Main in care citesc din fisier si pentru fiecare tip de proiectil calculez datele necesare
 * proiectarii si completez matricea
 * Tot in Clasa Main fac si scrierea in fisier
 * @author Dorinela
 *
 */
public class Main {
	
	//Date din fisierul de intrare
	static ProjectileNames projectile_names; //numele proiectilului
	static Symbols symbol;//simbolul asociat fiecarui tip de proiectil
	static TimeManager time_manager = new TimeManager();//timpul lansarii unui proiectil
	static DrawManager draw_manager;
	static Projectile projectile;
	static Screen screen = new Screen();
	static BasicShape basic_shape;
	static Point point;
	static char[][] matrix;
	
	
	
	public static void main(String[] args) {
		
		String file_in = args[0]; //numele fisierului de intrare
		int ex = 0,ey = 0; //dimensiunile ecranului
		int N = 0; //numarul de proiectile;
		int ref = 0; //referinta
		int dist = 0;//distanta intre student si ecran
		int posx = 0, posy = 0;//coordonatele punctului P
		int h = 0, m = 0, s = 0;//ora, minutul, secunda
		ArrayList<String> linie = new ArrayList<String>();//urmatoarele N linii din fisier
		
		 //citire din fisier 
	     try{
	    	 InputStream ips=new FileInputStream(file_in); 
	         InputStreamReader ipsr=new InputStreamReader(ips);
	         BufferedReader br=new BufferedReader(ipsr);
	         String line;
	         
	         line = br.readLine();
	         String[] dim = line.split(" ");
	         //dimensiunile matricii
	         ex = Integer.parseInt(dim[0]);
	         ey = Integer.parseInt(dim[1]);
	        
	         line = br.readLine();
	         N = Integer.parseInt(line);//numarul de proiectile
	         
	         while ((line=br.readLine())!=null){
	            	linie.add(line);//adaug in ArrayList-ul linie proiectilele aruncate de un student impreuna cu datele specifice
	            }
	         br.close();//inchid fisierul
	     }
	     catch (Exception e){
	            System.out.println(e.toString());
	        }
	     
	   //initializare matrice
	     screen	= new Screen(ex, ey);
	     matrix = new char[ex][ey];
	     for(int i = 0; i < ex; i++){
	    	 for(int j = 0; j < ey; j++){
	    		 matrix[i][j] = '.';
	    	 }
	     }
	     Point nu_transforma1 = new Point();
	     Point nu_transforma2 = new Point();
	     Point nu_transforma3 = new Point();
	     
	     Point direct = new Point();
	     Point direct1 = new Point();
	     Point direct2 = new Point();
	     Point direct3 = new Point();
	     Point direct4 = new Point();
	     Point direct5 = new Point();
	     Point direct6 = new Point();
	     
	     ArrayList<Point> puncte = new ArrayList<Point>();
	     
	     //pentru fiecare element din ArrayList-ul linie  aplic split ca obtin tipul proiectilului,
	     //referinta, distanta, ora, minutul, secunda si coordonatele punctului P
	     //dupa care proiectez figura pe ecran si completez matricea pe baza rezultatelor obtinute
	     
	    for(int i = 0; i < linie.size(); i++){
	    	 //aplicare split pentru fiecare element din "linie"
	    	//si introducerea intr-un vector de Stringuri
	    	 String[] linie_split = linie.get(i).split("[ ,:]");
	    	 String tip = linie_split[0];//primul element din vectorul de stringuri este tipul proiectilului
	    	 ref = Integer.parseInt(linie_split[1]);//referinta
	    	 h = Integer.parseInt(linie_split[2]);//ora
	    	 m = Integer.parseInt(linie_split[3]);//minutul
	    	 s = Integer.parseInt(linie_split[4]);//secunda
	    	 time_manager.setTime(h, m, s);//setare ora, minut si secunda
	    	 dist = Integer.parseInt(linie_split[5]);//distanta intre student si ecran
	    	 posx = Integer.parseInt(linie_split[6]);//coordonata X a punctului P
	    	 posy = Integer.parseInt(linie_split[7]);//coordonata Y a punctului P
	    	
	    	 //Mai departe verific ce tip de proiectil am si aplic transformarile specifice
	    	 
	    	 //daca lansez un proiectil de tipul SimpleShell
	    	 if(projectile_names.SIMPLE_SHELL.equals(tip)){
	    		
	    		 Point pp = new Point(posx, posy);//Creez punctul P
	    		 Point centru_greutate = new Point(pp.getX(), pp.getY());//calculare centru greutate
				 SimpleShell simpleshell = new SimpleShell(screen,ref,time_manager);//creare obiect de tipul SimpleShell
				 simpleshell.shoot(dist, centru_greutate);//apelare metoda shoot
    			 simpleshell.pu.draw(screen, ref, centru_greutate);//apelare metoda draw
    			 matrix = screen.getMatrix();//returnare matricea rezultat
    			
	    	 }
	    	 
	    	 //daca lansez un proiectil de tipul Shrapnel
	    	 if(projectile_names.SHRAPNEL.equals(tip)){
	    		 
	    		 //calculez distantele dupa care proictilul se transforma
	    		 int d5 = 42 + (5 * 5 * time_manager.getHour() + 5 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d7 = 42 + (7 * 7 * time_manager.getHour() + 7 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		
	    		 Point pp = new Point(posx,posy);//creare punct P
	    		 int dd = -d5/10 - 5;
    			 int ref1 = ref + dd;//calculare ref final
    			 Point centru_greutate = new Point(pp.getX(), pp.getY());//creare centru greutate
    			 centru_greutate = centru_greutate.translate((int)(Math.round(Math.sin(d5*Math.PI/2))),0);//calcul centru greutate
    
    			 //actualizare date dupa ce Shrapnel parcurge d5 si se transforma in  SpiderShot
    			 int dist2 = dist - d5;//distanta ramasa
    			 Point centru_greutate1 = new Point(centru_greutate.getX(), centru_greutate.getY());//centru greutate al noului proietil
    			 //calcul centru greutate
    			 centru_greutate1 = centru_greutate1.translate((int)(Math.round(Math.sin(d7*(Math.PI/2)))), (int)(Math.round(Math.cos(d7*(Math.PI/2)))));
    			 int dd2 = -dist2/10 - 7;
    			 int ref2 = ref1 + dd2;//calcul ref final pentru SpiderShot
    			 
    			 
    			 
    			 if(dist < d5){//in acest caz Shrapnel nu se transforma, deci pe ecran se va proiecta Shrapnel

    				 //calculare date pentru desenare Shrapnel si completare matrice
    				 Point nu_transforma = new Point(pp.getX(), pp.getY());
    				 nu_transforma = nu_transforma.translate((int)(Math.round(Math.sin(dist*(Math.PI/2)))), 0);
    				 int ref_nu = ref - dist/10 - 5;
    				 Shrapnel shrapnel = new Shrapnel(screen, ref, time_manager); 
    				 shrapnel.shoot(dist, nu_transforma);
	    			 shrapnel.p.draw(screen, ref_nu,nu_transforma);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			
    			
    			 if(dist > d5 && dist - d5 < d7){//In acest caz Shrapnel se transforma in SpiderShot
    				 
    				 //calculare date pentru desenare SpiderShot si completare matrice
    				 int ref_2 = ref1 - dist2/10 - 7;
    				 Point c = new Point(centru_greutate.getX(), centru_greutate.getY());
    				 c = c.translate((int)(Math.round(Math.sin(dist2*(Math.PI/2)))), (int)(Math.round(Math.cos(dist2*(Math.PI/2)))));
	    			 SpiderShot spidershot = new SpiderShot(screen, ref1, time_manager);
	    			 spidershot.shoot(dist2, c);
	    			 spidershot.d.draw(screen, ref_2, c);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist - d5 - d7 > 0){//in acest caz pe ecran se va proiecta SimpleShell
    				
    				 //calculare date pentru desenare SimpleShell si completare matrice
    				 Point c = new Point(centru_greutate.getX(), centru_greutate.getX());
    				 Point centru_greutate2 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
    				 SimpleShell simpleshell = new SimpleShell(screen,ref2,time_manager);
    				 simpleshell.shoot(dist-d5-d7, centru_greutate2);
	    			 simpleshell.pu.draw(screen, ref2, centru_greutate2);
	    			 matrix = screen.getMatrix();
	    			 direct = new Point (centru_greutate2.getX(), centru_greutate2.getY());
	    			 puncte.add(direct);
	    			
    			 }
    			 matrix[posx][posy] = '.';
    			 matrix[posy][posx] = '.';
    			
	    	 }
	    	 
	    	 //daca proiectez un proiectil de tipul HeatedShot
	    	 if(projectile_names.HEATED_SHOT.equals(tip)){
	    		 
	    		 //calculare distante dupa care HeatedShot se transforma
	    		 int d6 = 42 + (6 * 6 * time_manager.getHour() + 6 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d7 = 42 + (7 * 7 * time_manager.getHour() + 7 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		
	    		 Point pp = new Point(posx,posy);//punctul P
	    		 int dd = -d6/10 - 6;
    			 int ref1 = ref + dd;//calcul referinta
    			 Point centru_greutate = new Point(pp.getX(), pp.getY());//centru greutate
    			 centru_greutate = centru_greutate.translate(0,(int)(Math.round(Math.cos(d6*Math.PI/2))));//calcul centru greutate
    
    			 //date dupa distanta d6 cand HeatedShot se trensforma in SpiderShot
    			 int dist2 = dist - d6;//distanta ramasa
    			 Point centru_greutate1 = new Point(centru_greutate.getX(), centru_greutate.getY());//centru greutate
    			 //calcul centru greutate
    			 centru_greutate1 = centru_greutate1.translate((int)(Math.round(Math.sin(d7*(Math.PI/2)))), (int)(Math.round(Math.cos(d7*(Math.PI/2)))));
    			 int dd2 = -d7/10 - 7;
    			 int ref2 = ref1 + dd2;//calcul referinta
    			 
    			
    			 if(dist < d6){//in acest caz proiectilul nu se transforma
    				 
    				 //calcul date necesare desenarii pe ecran si completare matrice
    				 Point nu_transforma = new Point(pp.getX(), pp.getY());
    				 nu_transforma = nu_transforma.translate(0, (int)(Math.round(Math.cos(dist*Math.PI/2))));
    				 int ref_nu = ref - dist/10 - 6;
    				 HeatedShot heatedshot = new HeatedShot(screen, ref, time_manager);
    				 heatedshot.shoot(dist, nu_transforma);
	    			 heatedshot.r.draw(screen, ref_nu,nu_transforma);
	    			 matrix = screen.getMatrix();
	    			 nu_transforma1 = new Point(nu_transforma.getX(), nu_transforma.getY());
	    			 nu_transforma1 = nu_transforma1.translate(ref_nu, 0);
	  
    			 }
    			 
    			 if(dist > d6 && dist - d6 < d7){//in acest caz proiectlul se transforma in SpiderShot
    				 
    				 //calcul date necesare desenarii pe ecran si completare matrice
    				 int ref_2 = ref1 - dist2/10 - 7;
    				 Point c = new Point(centru_greutate.getX(), centru_greutate.getY());
    				 c = c.translate((int)(Math.round(Math.sin(dist2*(Math.PI/2)))), (int)(Math.round(Math.cos(dist2*(Math.PI/2)))));
	    			 SpiderShot spidershot = new SpiderShot(screen, ref1, time_manager);
	    			 spidershot.shoot(dist2, c);
	    			 spidershot.d.draw(screen, ref_2, c);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist - d6 - d7 > 0){//in acest caz proiectilul devine SimpleShell
    				
    				 //calcul date necesare desenarii pe ecran si completare matrice
    				 SimpleShell simpleshell = new SimpleShell(screen,ref2,time_manager);
    				 simpleshell.shoot(dist-d6-d7, centru_greutate1);
	    			 simpleshell.pu.draw(screen, ref2, centru_greutate1);
	    			 matrix = screen.getMatrix();
	    			 direct1 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
	    			 puncte.add(direct1);
	    			
    			 }
    			 
    			 matrix[posx][posy] = '.';
	    	 }
	    	 
	    	 //daca proiectilul lansat este SpiderShot
	    	 if(projectile_names.SPIDER_SHOT.equals(tip)){
	    		 
	    		 //calcul d7 - dupa aceasta distanta proiectilul se transforma in SimpleShell
	    		 int d7 = 42 + (7 * 7 * time_manager.getHour() + 7 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 Point pp = new Point(posx,posy);//punctul P
	    		 int dd = -d7/10 - 7;
    			 int ref1 = ref + dd;//calcul referinta
    			 Point centru_greutate = new Point(pp.getX(), pp.getY());//cantru greutate
    			 //calcul centru greutate
    			 centru_greutate = centru_greutate.translate((int)(Math.round(Math.sin(d7*(Math.PI/2)))),(int)(Math.round(Math.cos(d7*(Math.PI/2)))));
    
	    		 if(dist < d7){//in acest caz proiectilul nu se transforma
	    			
	    			 //calcul date si proiectare e ecran (completare matrice)
	    			 Point nu_transforma = new Point(pp.getX(), pp.getY());
	    			 nu_transforma = nu_transforma.translate((int)(Math.round(Math.sin(dist*(Math.PI/2)))),(int)(Math.round(Math.cos(dist*(Math.PI/2)))));
	    			 int ref_nu = ref - dist/10 - 7;
	    			 SpiderShot spidershot = new SpiderShot(screen, ref1, time_manager);
	    			 spidershot.shoot(dist, nu_transforma);
	    			 spidershot.d.draw(screen, ref_nu, nu_transforma);
	    			 matrix = screen.getMatrix();
	    			
	    		 }
	    		 else{//in acest caz proiectilul devine SimpleShell
	    			
	    			//calcul date si proiectare e ecran (completare matrice)
	    			 SimpleShell simpleshell = new SimpleShell(screen,ref1,time_manager);
    				 simpleshell.shoot(dist, centru_greutate);
	    			 simpleshell.pu.draw(screen, ref1, centru_greutate);
	    			 matrix = screen.getMatrix();
	    			 direct2 = new Point(centru_greutate.getX(), centru_greutate.getY());
	    			 puncte.add(direct2);
	    			
	    		 }
	    		 matrix[posx][posy] = '.';
	    	 }
	    	 
	    	 //daca proiectilul lansat este TriGrapeShot
	    	 if(projectile_names.TRI_GRAPE_SHOT.equals(tip)){
	    		 
	    		 //calculare distante dupa care proiectilul se transforma
	    		 int d1 = 42 + (1 * 1 * time_manager.getHour() + 1 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d5 = 42 + (5 * 5 * time_manager.getHour() + 5 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d7 = 42 + (7 * 7 * time_manager.getHour() + 7 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		
	    		 Point pp = new Point(posx,posy);//punctul P
	    		 int dd = -d1/10 - 1;
    			 int ref1 = ref + dd;//calcul referinta
    			 Point centru_greutate = new Point(pp.getX(), pp.getY());//centru greutate
    			 centru_greutate = centru_greutate.translate(d1,0);//calcul centru greutate
    
    			 //datele dupa ce proiectilul se transforma in Shrapnel
    			 int dist2 = dist - d1;//distanta ramasa
    			 Point centru_greutate1 = new Point(centru_greutate.getX(), centru_greutate.getY());
    			 //calculnoul centru de greutate
    			 centru_greutate1 = centru_greutate1.translate((int)(Math.round(Math.sin(d5*(Math.PI/2)))), 0);
    			 int dd2 = -d5/10 - 5;
    			 int ref2 = ref1 + dd2;//calcul referinta
    
    			 //date dupa ce proiectilul devine SpiderShot
    			 int dist3 = dist2 - d5;//distanta ramasa
    			 Point centru_greutate2 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
    			 //noul centru de greutate
    			 centru_greutate2 = centru_greutate2.translate((int)(Math.round(Math.sin(d7*Math.PI/2))), (int)(Math.round(Math.cos(d7*Math.PI/2))));
    			 int dd3 = -dist3/10 - 7;
    			 int ref3 = ref2 + dd3;//noua referinta
  
    			 if(dist < d1){//daca proiectilul nu se transforma
    				
    				 //calcul date si proiectare pe ecran(completare matrice)
    				 int ref_nu = ref - dist/10 - 1;
    				 Point nu_transformare = new Point(pp.getX(), pp.getY());
    				 nu_transformare = nu_transformare.translate(dist, 0);
    				 TriGrapeShot trigrapeshot = new TriGrapeShot(screen, ref, time_manager);
    				 trigrapeshot.shoot(dist, pp);
	    			 trigrapeshot.t.draw(screen, ref_nu,nu_transformare);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist > d1 && dist - d1 < d5){//daca proiectilul se transforma in Shrapnel
    				 
    				//calcul date si proiectare pe ecran(completare matrice)
    				 Point c = new Point(centru_greutate.getX(), centru_greutate.getY());
    				 c = c.translate((int)(Math.round(Math.sin(dist2*(Math.PI/2)))), 0);
    				 int ref_2 = ref1 - dist2/10 - 5;
    				 Shrapnel shrapnel = new Shrapnel(screen, ref1, time_manager);
    				 shrapnel.shoot(dist2, c);
    				 shrapnel.p.draw(screen, ref_2, c);
	    			 matrix = screen.getMatrix();
	    			 
    			 }
    			 if(dist - d1 > d5 && dist - d1 - d5 < d7){//daca proiectilul se transforma in SpiderShot
    				 
     				//calcul date si proiectare pe ecran(completare matrice)
    				 Point c1 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
    				 c1 = c1.translate((int)(Math.round(Math.sin(dist3*Math.PI/2))), (int)(Math.round(Math.cos(dist3*Math.PI/2))));
    				 int ref_3 = ref2 - dist3/10 - 7;
    				 SpiderShot spidershot = new SpiderShot(screen, ref2, time_manager);
    				 spidershot.shoot(dist3, c1);
    				 spidershot.d.draw(screen, ref_3, c1);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist - d1 - d5 - d7 > 0){//dacaproiectilul se transforma in SimpleShell
    				 
    				//calcul date si proiectare pe ecran(completare matrice)
    				 Point centru_greutate3 = new Point(centru_greutate2.getX(), centru_greutate2.getY());
    				 SimpleShell simpleshell = new SimpleShell(screen,ref3,time_manager);
    				 simpleshell.shoot(dist - d1 - d5 - d7, centru_greutate3);
	    			 simpleshell.pu.draw(screen, ref3, centru_greutate3);
	    			 matrix = screen.getMatrix();
	    			 direct3 = new Point(centru_greutate3.getX(), centru_greutate3.getY());
	    			 puncte.add(direct3);
	    			 
    			 }
    			 matrix[pp.getX()][pp.getY()] = '.';
    			 matrix[pp.getY()][pp.getX()] = '.';
	    	 }
	    	 
	    	 //daca proiectilul lansat este Carcas
	    	 if(projectile_names.CARCASS.equals(tip)){
	    		 
	    		 //calcul distante dupa care proiectilul se transforma
	    		 int d2 = 42 + (2 * 2 * time_manager.getHour() + 2 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d6 = 42 + (6 * 6 * time_manager.getHour() + 6 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d7 = 42 + (7 * 7 * time_manager.getHour() + 7 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		
	    		 Point pp = new Point(posx,posy);//punctul P
	    		 int dd = -d2/10 - 2;
    			 int ref1 = ref + dd;//calcul referinta
    			 Point centru_greutate = new Point(pp.getX(), pp.getY());
    			 centru_greutate = centru_greutate.translate(0,d2);//calcul centru greutate
    
    			 //date dupa ce proiectilul se transforma in HeatedShot
    			 int dist2 = dist - d2;
    			 Point centru_greutate1 = new Point(centru_greutate.getX(), centru_greutate.getY());
    			 centru_greutate1 = centru_greutate1.translate(0,(int)(Math.round(Math.cos(d6*(Math.PI/2)))));
    			 int dd2 = -d6/10 - 6;
    			 int ref2 = ref1 + dd2;
    
    			 //date dupa ce proiectilul se transforma in SpiderShot
    			 int dist3 = dist2 - d6;
    			 Point centru_greutate2 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
    			 centru_greutate2 = centru_greutate2.translate((int)(Math.round(Math.sin(d7*Math.PI/2))), (int)(Math.round(Math.cos(d7*Math.PI/2))));
    			 int dd3 = -dist3/10 - 7;
    			 int ref3 = ref2 + dd3;
    			
    			 if(dist < d2){//daca proiectilul nu se transforma
    				
    				 //calcul date necesare proiectarii pe ecran(completare matrice)
    				 Point nu_transforma = new Point(pp.getX(), pp.getY());
    				 nu_transforma = nu_transforma.translate(0, dist);
    				 Carcass carcass = new Carcass(screen, ref, time_manager);
    				 int ref_nu = ref - dist/10 - 2;
    				 carcass.shoot(dist, pp);
	    			 carcass.p.draw(screen, ref_nu,nu_transforma);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist > d2 && dist - d2 < d6){//daca proiectilul se transforma in HeatedShot

    				 //calcul date necesare proiectarii pe ecran(completare matrice)
    				 Point c = new Point(centru_greutate.getX(), centru_greutate.getY());
    				 c = c.translate(0,(int)(Math.round(Math.cos(dist2*(Math.PI/2)))));
    				 int ref_2 = ref1 - dist2/10 - 6;
    				 HeatedShot heatedshot = new HeatedShot(screen, ref1, time_manager);
    				 heatedshot.shoot(dist2, c);
    				 heatedshot.r.draw(screen, ref_2, c);
	    			 matrix = screen.getMatrix();
	    			 nu_transforma2 = new Point(c.getX(), c.getY());
	    			 nu_transforma2  = nu_transforma2.translate(ref_2, 0);
	    			
    			 }
    			 if(dist - d2 > d6 && dist - d2 - d6 < d7){//daca proiectilul se transforma in SpiderShot

    				 //calcul date necesare proiectarii pe ecran(completare matrice)
    				 Point c1 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
    				 c1 = c1.translate((int)(Math.round(Math.sin(dist3*Math.PI/2))), (int)(Math.round(Math.cos(dist3*Math.PI/2))));
    				 int ref_3 = ref2 - dist3/10 - 7;
    				 SpiderShot spidershot = new SpiderShot(screen, ref2, time_manager);
    				 spidershot.shoot(dist3, c1);
    				 spidershot.d.draw(screen, ref_3, c1);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist - d2 - d6 - d7 > 0){//daca proiectilul se transforma in SimpleShell

    				//calcul date necesare proiectarii pe ecran(completare matrice)
    				 Point centru_greutate3 = new Point(centru_greutate2.getX(), centru_greutate2.getY());
    				 SimpleShell simpleshell = new SimpleShell(screen,ref3,time_manager);
    				 simpleshell.shoot(dist - d2 - d6 - d7, centru_greutate3);
	    			 simpleshell.pu.draw(screen, ref3, centru_greutate3);
	    			 matrix = screen.getMatrix();
	    			 direct4 = new Point(centru_greutate3.getX(), centru_greutate3.getY());
	    			 puncte.add(direct4);
	    			
    			 }
    			 matrix[pp.getX()][pp.getY()] = '.';
	    	 }
	    	 
	    	 //daca proiectilul este CanisterShot
	    	 if(projectile_names.CANNISTER_SHOT.equals(tip)){
	    		 
	    		 //calculez datele pentru care proiectilul se transforma 
	    		 int d3 = 42 + (3 * 3 * time_manager.getHour() + 3 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d6 = 42 + (6 * 6 * time_manager.getHour() + 6 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d7 = 42 + (7 * 7 * time_manager.getHour() + 7 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 
	    		 Point pp = new Point(posx,posy);//punctul P
	    		 int dd = -d3/10 - 3;
    			 int ref1 = ref + dd;//referinta
    			 Point centru_greutate = new Point(pp.getX(), pp.getY());
    			 centru_greutate = centru_greutate.translate(-d3,0);//centru greutate
    
    			 //date dupa ce proiectilul devine HeatedShot
    			 int dist2 = dist - d3;
    			 Point centru_greutate1 = new Point(centru_greutate.getX(), centru_greutate.getY());
    			 centru_greutate1 = centru_greutate1.translate(0,(int)(Math.round(Math.cos(d6*(Math.PI/2)))));
    			 int dd2 = -d6/10 - 6;
    			 int ref2 = ref1 + dd2;
    
    			 //date dupa ce proiectilul devine SpiderShot
    			 int dist3 = dist2 - d6;
    			 Point centru_greutate2 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
    			 centru_greutate2 = centru_greutate2.translate((int)(Math.round(Math.sin(d7*Math.PI/2))), (int)(Math.round(Math.cos(d7*Math.PI/2))));
    			 int dd3 = -dist3/10 - 7;
    			 int ref3 = ref2 + dd3;
    			 
    			 if(dist < d3){//daca proiectilul nu se transforma
    				
    				 //calcul date necesare proiectarii pe ecran(completare matrice)
    				Point nu_transforma = new Point(pp.getX(), pp.getY());
    				nu_transforma = nu_transforma.translate(-dist, 0);
    				int ref_nu = -dist/10 - 3 + ref;
    				CanisterShot canistershot = new CanisterShot(screen, ref, time_manager);
    			    canistershot.shoot(dist, nu_transforma);
	    			canistershot.d.draw(screen, ref_nu,nu_transforma);
	    			matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist > d3 && dist - d3 < d6){//daca proiectilul se transforma in HeatedShot

    				 //calcul date necesare proiectarii pe ecran(completare matrice)
    				 Point c = new Point(centru_greutate.getX(), centru_greutate.getY());
    				 c = c.translate(0,(int)(Math.round(Math.cos(dist2*(Math.PI/2)))));
    				 int ref_2 = ref1 - dist2/10 - 6;
    				 HeatedShot heatedshot = new HeatedShot(screen, ref1, time_manager);
    				 heatedshot.shoot(dist2, c);
    				 heatedshot.r.draw(screen, ref_2, c);
	    			 matrix = screen.getMatrix();
	    			 nu_transforma3 = new Point(c.getX(), c.getY());
	    			 nu_transforma3  = nu_transforma3.translate(ref_2, 0);
	    			
    			 }
    			 if(dist - d3 > d6 && dist - d3 - d6 < d7){//daca proiectilul se transforma in SpiderShot

    				 //calcul date necesare proiectarii pe ecran(completare matrice)
    				 Point c1 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
    				 c1 = c1.translate((int)(Math.round(Math.sin(dist3*Math.PI/2))), (int)(Math.round(Math.cos(dist3*Math.PI/2))));
    				 int ref_3 = ref2 - dist3/10 - 7;
    				 SpiderShot spidershot = new SpiderShot(screen, ref2, time_manager);
    				 spidershot.shoot(dist3, c1);
    				 spidershot.d.draw(screen, ref_3, c1);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist - d3 - d6 - d7 > 0){//daca proiectilul se transforma in SimpleShell
    				 
    				 //calcul date necesare proiectarii pe ecran(completare matrice)
    				 Point centru_greutate3 = new Point(centru_greutate2.getX(), centru_greutate2.getY());
    				 SimpleShell simpleshell = new SimpleShell(screen,ref3,time_manager);
    				 simpleshell.shoot(dist - d3 - d6 - d7, centru_greutate3);
	    			 simpleshell.pu.draw(screen, ref3, centru_greutate3);
	    			 matrix = screen.getMatrix();
	    			 direct5 = new Point(centru_greutate3.getX(), centru_greutate3.getY());
	    			 puncte.add(direct5);
	    			
    			 }
    			 matrix[posx][posy] = '.';
    			 matrix[posy][posx] = '.';
		    }
	    	 
	    	 //daca proiectilul lansat este ChainShot
	    	 if(projectile_names.CHAIN_SHOT.equals(tip)){
	    		 
	    		 //calcul distante dupa care proiectilul se transforma
	    		 int d4 = 42 + (4 * 4 * time_manager.getHour() + 4 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d5 = 42 + (5 * 5 * time_manager.getHour() + 5 * time_manager.getMinute() + time_manager.getSecond())%42;
	    		 int d7 = 42 + (7 * 7 * time_manager.getHour() + 7 * time_manager.getMinute() + time_manager.getSecond())%42;
	    	
	    		 Point pp = new Point(posx,posy);//punctul P
	    		 int dd = -d4/10 - 4;
    			 int ref1 = ref + dd;//referinta
    			 Point centru_greutate = new Point(pp.getX(), pp.getY());
    			 centru_greutate = centru_greutate.translate(0,-d4);//centru greutate
    
    			 //date dupa ce proiectilul se transforma in Shrapnel
    			 int dist2 = dist - d4;
    			 Point centru_greutate1 = new Point(centru_greutate.getX(), centru_greutate.getY());
    			 centru_greutate1 = centru_greutate1.translate((int)(Math.round(Math.sin(d5*(Math.PI/2)))), 0);
    			 int dd2 = -d5/10 - 5;
    			 int ref2 = ref1 + dd2;
    
    			 //date dupa ce proiectilul se transforma in SpiderShot
    			 int dist3 = dist2 - d5;
    			 Point centru_greutate2 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
    			 centru_greutate2 = centru_greutate2.translate((int)(Math.round(Math.sin(d7*Math.PI/2))), (int)(Math.round(Math.cos(d7*Math.PI/2))));
    			 int dd3 = -dist3/10 - 7;
    			 int ref3 = ref2 + dd3;
    			
    			 if(dist < d4){//daca proiectilul nu se transforma
    				
    				//calcul date pentru proiectare pe ecran(completare matrice)
    				 Point nu_transforma = new Point(pp.getX(),pp.getY());
    				 nu_transforma = nu_transforma.translate(0, -dist);
    				 int ref_nu = ref - dist/10 - 4;
    				 ChainShot chainshot = new ChainShot(screen, ref, time_manager);
    				 chainshot.shoot(dist, pp);
	    			 chainshot.t.draw(screen, ref_nu,nu_transforma);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist > d4 && dist - d4 < d5){//daca proiectilul se transforma in Shrapnel

    				 //calcul date pentru proiectare pe ecran(completare matrice)
    				 Point c = new Point(centru_greutate.getX(), centru_greutate.getY());
    				 c = c.translate((int)(Math.round(Math.sin(dist2*(Math.PI/2)))), 0);
    				 int ref_2 = ref1 - dist2/10 - 5;
    				 Shrapnel shrapnel = new Shrapnel(screen, ref1, time_manager);
    				 shrapnel.shoot(dist2, c);
    				 shrapnel.p.draw(screen, ref_2, c);
	    			 matrix = screen.getMatrix();
	    			 
    			 }
    			 if(dist - d4 > d5 && dist - d4 - d5 < d7){//daca proiectilul se transforma in SpiderShot
    				 
    				 //calcul date pentru proiectare pe ecran(completare matrice)
    				 Point c1 = new Point(centru_greutate1.getX(), centru_greutate1.getY());
    				 c1 = c1.translate((int)(Math.round(Math.sin(dist3*Math.PI/2))), (int)(Math.round(Math.cos(dist3*Math.PI/2))));
    				 int ref_3 = ref2 - dist3/10 - 7;
    				 SpiderShot spidershot = new SpiderShot(screen, ref3, time_manager);
    				 spidershot.shoot(dist3, c1);
    				 spidershot.d.draw(screen, ref_3, c1);
	    			 matrix = screen.getMatrix();
	    			
    			 }
    			 if(dist - d4 - d5 - d7 > 0){//daca proiectilul se transforma in SimpleShell
    				 
    				 //calcul date pentru proiectare pe ecran(completare matrice)
    				 Point centru_greutate3 = new Point(centru_greutate2.getX(), centru_greutate2.getY());
    				 SimpleShell simpleshell = new SimpleShell(screen,ref3,time_manager);
    				 simpleshell.shoot(dist - d4 - d5 - d7, centru_greutate3);
	    			 simpleshell.pu.draw(screen, ref3, centru_greutate3);
	    			 matrix = screen.getMatrix();
	    			 direct6 = new Point(centru_greutate3.getX(), centru_greutate3.getY());
	    			 puncte.add(direct6);
	    			
    			 }
    			
    			 matrix[pp.getX()][pp.getY()] = '.';
	    	 }
	     }
	 
	    if(nu_transforma1.getY()-1 > 1 && nu_transforma1.getX()-1 > 1 && nu_transforma1.getX()+1 < ex && nu_transforma1.getY()+1 < ex && matrix[nu_transforma1.getY()-1][nu_transforma1.getX()-1] == Symbols.RHOMBUS_SYMBOL && matrix[nu_transforma1.getY()+1][nu_transforma1.getX()-1] == Symbols.RHOMBUS_SYMBOL)
	    	matrix[nu_transforma1.getY()][nu_transforma1.getX()] = Symbols.RHOMBUS_SYMBOL;
	    
	    if(nu_transforma2.getY()-1 > 1 && nu_transforma2.getX()-1 > 1 && nu_transforma2.getX()+1 < ex && nu_transforma2.getY()+1 < ex && matrix[nu_transforma2.getY()-1][nu_transforma2.getX()-1] == Symbols.RHOMBUS_SYMBOL && matrix[nu_transforma2.getY()+1][nu_transforma2.getX()-1] == Symbols.RHOMBUS_SYMBOL)
	    	matrix[nu_transforma2.getY()][nu_transforma2.getX()] = Symbols.RHOMBUS_SYMBOL;
	    
	    if(nu_transforma3.getY()-1 > 1 && nu_transforma3.getX()-1 > 1 && nu_transforma3.getX()+1 < ex && nu_transforma3.getY()+1 < ex && matrix[nu_transforma3.getY()-1][nu_transforma3.getX()-1] == Symbols.RHOMBUS_SYMBOL && matrix[nu_transforma3.getY()+1][nu_transforma3.getX()-1] == Symbols.RHOMBUS_SYMBOL)
	    	matrix[nu_transforma3.getY()][nu_transforma3.getX()] = Symbols.RHOMBUS_SYMBOL;
	    
	    for(int i = 0; i < puncte.size(); i++){
	    	if(puncte.get(i).getX() > 1 && puncte.get(i).getY() > 1 && puncte.get(i).getX() < ex && puncte.get(i).getY() < ex)
	    		if(matrix[puncte.get(i).getY()][puncte.get(i).getX()] == Symbols.SCREEN_SYMBOL)
	    			matrix[puncte.get(i).getY()][puncte.get(i).getX()] = Symbols.DOT_SYMBOL;
	    }
	    
	    for(int i = 3; i < ex-2; i++){
	    	for(int j = 3; j < ey-2; j++){
	    		if(matrix[i-1][j] == Symbols.RECTANGLE_SYMBOL && matrix[i+1][j] == Symbols.RECTANGLE_SYMBOL && matrix[i-2][j] == Symbols.RECTANGLE_SYMBOL && matrix[i+2][j] == Symbols.RECTANGLE_SYMBOL && matrix[i][j] == Symbols.SCREEN_SYMBOL)
	    			matrix[i][j] = Symbols.RECTANGLE_SYMBOL;
	    		
	    		if(matrix[i][j-1] == Symbols.RECTANGLE_SYMBOL && matrix[i][j+1] == Symbols.RECTANGLE_SYMBOL && matrix[i][j-2] == Symbols.RECTANGLE_SYMBOL && matrix[i][j+2] == Symbols.RECTANGLE_SYMBOL && matrix[i][j] == Symbols.SCREEN_SYMBOL)
	    			matrix[i][j] = Symbols.RECTANGLE_SYMBOL;
	    	}
	    }

	      String fisier_iesire = file_in + "_out";//numele fisierului de iesire
	      //scriere in fisier
	    	try {
	    	  FileWriter f = new FileWriter(fisier_iesire);
	          BufferedWriter output = new BufferedWriter(f);

	  	    for(int i = 0; i < ex; i++){
	         for(int j = 0; j < ey; j++){
	        	 output.write(matrix[i][j]);
	          }
	         output.newLine();
	  	    }
	          output.close();
	        } catch ( IOException e ) {
	           e.printStackTrace();
	        }
	    	
	}
}
