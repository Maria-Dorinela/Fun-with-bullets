package ProcessingManagers;

/**
 * Time object
 */
public class TimeManager {
	private int h,m,s;

	// TODO => implement the body of the class (set class fields, make ways 
	// 			for other classes to work with a TimeManager object)
	
	/**
	 * Constructor implicit
	 */
	public TimeManager(){
		
	}
	/**
	 * Constructor cu 2 parametri, initializare
	 * @param h
	 * @param m
	 * @param s
	 */
	public TimeManager(int h, int m,int s){
		this.h = h;
		this.m = m;
		this.s = s;
	}
	
	/**
	 * 
	 * @return ora
	 */
	public int getHour(){
		return h;
	}
	
	/**
	 * 
	 * @return minutul
	 */
	public int getMinute(){
		return m;
	}
	
	/**
	 * 
	 * @return secunda
	 */
	public int getSecond(){
		return s;
	}
	
	/**
	 * Metoda care seteaza ora, minutul si secunda
	 * @param hour - ora
	 * @param minute - minutul
	 * @param second - secunda
	 */
	public void setTime(int hour, int minute, int second){
		this.h = hour;
		this.m = minute;
		this.s = second;
		
	}	
}