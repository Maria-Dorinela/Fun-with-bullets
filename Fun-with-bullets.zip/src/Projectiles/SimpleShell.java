package Projectiles;

import ProcessingManagers.TimeManager;
import Screen.Screen;
import Shapes.Point;
import Shapes.Punct;

/**
 * Clasa SimpleShell care extinde clasa Projectile
 * @author Dorinela
 *
 */
public class SimpleShell extends Projectile{

	public Punct pu = new Punct();
	public SimpleShell(Screen screen, int ref, TimeManager currentTime) {
		super(screen, ref, currentTime);
		// TODO Auto-generated constructor stub
		this.shape = pu;
	}

	@Override
	public void shoot(int dist, Point shooterPosition) {
		// TODO Auto-generated method stub
		dist = this.shapeChangingDist;
		
	}

	@Override
	protected void hitScreenAction(Point shooterPosition, int ref) {
		// TODO Auto-generated method stub
		this.shape.draw(this.screen, ref, shooterPosition);	
	
	}

}
