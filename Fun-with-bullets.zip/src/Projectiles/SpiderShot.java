package Projectiles;

import ProcessingManagers.TimeManager;
import Screen.Screen;
import Shapes.Dreptunghi;
import Shapes.Point;

/**
 * Clasa SpiderShot care extinde clasa SimpleShell
 * @author Dorinela
 *
 */
public class SpiderShot extends SimpleShell{
	
	public Dreptunghi d = new Dreptunghi();
	public SpiderShot(Screen screen, int ref, TimeManager currentTime) {
		super(screen, ref, currentTime);
		// TODO Auto-generated constructor stub
		this.shape = d;
	}
	public void shoot(int dist, Point shooterPosition) {
		// TODO Auto-generated constructor stub
		dist = this.shapeChangingDist;
	}

	@Override
	protected void hitScreenAction(Point shooterPosition, int ref) {
		// TODO Auto-generated method stub
		this.shape.draw(this.screen, ref, shooterPosition);
		
	}

}
