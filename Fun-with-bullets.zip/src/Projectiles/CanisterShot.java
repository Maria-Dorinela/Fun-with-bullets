package Projectiles;

import ProcessingManagers.TimeManager;
import Screen.Screen;
import Shapes.Dreptunghi;
import Shapes.Point;

/**
 * Clasa CanisterShot care extinde clasa HeatedShot
 * @author Dorinela
 *
 */
public class CanisterShot extends HeatedShot{

	public Dreptunghi d = new Dreptunghi();
	public CanisterShot(Screen screen, int ref, TimeManager currentTime) {
		super(screen, ref, currentTime);
		// TODO Auto-generated constructor stub
		this.shape = d;
	}
	
	public void shoot(int dist, Point shooterPosition) {
		// TODO Auto-generated constructor stub
		dist = this.shapeChangingDist;
		
	}

	@Override
	protected void hitScreenAction(Point shooterPosition, int ref) {
		// TODO Auto-generated method stub
		this.shape.draw(this.screen, ref, shooterPosition);
		
	}

}
