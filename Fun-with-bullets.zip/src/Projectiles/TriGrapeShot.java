package Projectiles;

import ProcessingManagers.TimeManager;
import Screen.Screen;
import Shapes.Point;
import Shapes.Triunghi;

/**
 * Clasa TriGrapeShot care extinde clasa Shrapnel
 * @author Dorinela
 *
 */
public class TriGrapeShot extends Shrapnel{

	public Triunghi t = new Triunghi();
	public TriGrapeShot(Screen screen, int ref, TimeManager currentTime) {
		super(screen, ref, currentTime);
		// TODO Auto-generated constructor stub
		this.shape = t;
	}
	
	@Override
	public void shoot(int dist, Point shooterPosition) {
		// TODO Auto-generated method stub
		dist = this.shapeChangingDist;
	
	}

	@Override
	protected void hitScreenAction(Point shooterPosition, int ref) {
		// TODO Auto-generated method stub
		this.shape.draw(this.screen, ref, shooterPosition);	
	}

}
