package Projectiles;

import ProcessingManagers.TimeManager;
import Screen.Screen;
import Shapes.*;
/**
 * Clasa Shrapnel care extinde clasa SpiderShot
 * @author Dorinela
 *
 */
public class Shrapnel extends SpiderShot{

	public Patrat p = new Patrat();
	public Shrapnel(Screen screen, int ref, TimeManager currentTime) {
		super(screen, ref, currentTime);
		// TODO Auto-generated constructor stub
		this.shape = p;
	}
	
	@Override
	public void shoot(int dist, Point shooterPosition) {
		// TODO Auto-generated method stub
		dist = this.shapeChangingDist;
		
	}

	@Override
	protected void hitScreenAction(Point shooterPosition, int ref) {
		// TODO Auto-generated method stub
		this.shape.draw(this.screen, ref, shooterPosition);	
	}
}
